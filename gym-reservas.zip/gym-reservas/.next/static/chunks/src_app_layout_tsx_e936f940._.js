(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_layout_tsx_e936f940._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_layout_tsx_e936f940._.js",
  "chunks": [
    "static/chunks/node_modules_bootstrap_dist_css_bootstrap_min_104c2c84.css"
  ],
  "source": "dynamic"
});
