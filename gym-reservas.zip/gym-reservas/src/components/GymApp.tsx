"use client";

import React, { useState } from "react";
import { Container, Button, ListGroup } from "react-bootstrap";
import ResumenReserva from "./ResumenReserva"; // Importa correctamente

const clasesDisponibles = [
  { id: 1, nombre: "Yoga", cupos: 5 },
  { id: 2, nombre: "Spinning", cupos: 8 },
  { id: 3, nombre: "Pesas", cupos: 10 },
];

const GymApp = () => {
  const [clases, setClases] = useState(clasesDisponibles);
  const [reservas, setReservas] = useState<number[]>([]);

  const reservarClase = (id: number) => {
    setClases((prevClases) =>
      prevClases.map((clase) =>
        clase.id === id && clase.cupos > 0
          ? { ...clase, cupos: clase.cupos - 1 }
          : clase
      )
    );
    setReservas([...reservas, id]);
  };

  const cancelarReserva = (id: number) => {
    setClases((prevClases) =>
      prevClases.map((clase) =>
        clase.id === id ? { ...clase, cupos: clase.cupos + 1 } : clase
      )
    );
    setReservas(reservas.filter((reservaId) => reservaId !== id));
  };

  return (
    <Container className="mt-5">
      <h1 className="mb-4">Reserva de Clases en el Gimnasio</h1>
      <ListGroup>
        {clases.map((clase) => (
          <ListGroup.Item
            key={clase.id}
            className="d-flex justify-content-between align-items-center"
          >
            {clase.nombre} - Cupos: {clase.cupos}
            <Button
              variant="primary"
              disabled={clase.cupos === 0 || reservas.includes(clase.id)}
              onClick={() => reservarClase(clase.id)}
            >
              Reservar
            </Button>
          </ListGroup.Item>
        ))}
      </ListGroup>

      {/* Aquí pasamos correctamente la función cancelarReserva */}
      <ResumenReserva reservas={reservas} cancelarReserva={cancelarReserva} />
    </Container>
  );
};

export default GymApp;
