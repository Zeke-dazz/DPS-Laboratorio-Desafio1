import React from "react";
import { Button } from "react-bootstrap";

// Definimos la estructura de una clase
interface Clase {
  id: number;
  nombre: string;
  cupos: number;
}

// Definimos las props del componente
interface ReservaClaseProps {
  clase: Clase;
  reservarClase: (id: number) => void;
}

const ReservaClase: React.FC<ReservaClaseProps> = ({ clase, reservarClase }) => {
  return (
    <Button
      variant="primary"
      disabled={clase.cupos === 0}
      onClick={() => reservarClase(clase.id)}
    >
      Reservar
    </Button>
  );
};



export default ReservaClase;

