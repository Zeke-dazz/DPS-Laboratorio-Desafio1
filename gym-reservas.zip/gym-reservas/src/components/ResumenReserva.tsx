import React from "react";
import { Button, ListGroup } from "react-bootstrap";

interface ResumenReservaProps {
  reservas: number[];
  cancelarReserva: (id: number) => void;
}

const ResumenReserva: React.FC<ResumenReservaProps> = ({ reservas, cancelarReserva }) => {
  return (
    <div>
      <h2>Resumen de Reservas</h2>
      <ListGroup>
        {reservas.length === 0 ? (
          <p>No hay reservas aún.</p>
        ) : (
          reservas.map((reservaId) => (
            <ListGroup.Item key={reservaId}>
              Clase ID: {reservaId}
              <Button variant="danger" onClick={() => cancelarReserva(reservaId)}>
                Cancelar
              </Button>
            </ListGroup.Item>
          ))
        )}
      </ListGroup>
    </div>
  );
};

export default ResumenReserva;

