import React from "react";
import ReservaClase from "./ReservaClase";

// Definimos la estructura de una clase
interface Clase {
  id: number;
  nombre: string;
  cupos: number;
}

// Definimos las props del componente
interface ListaClasesProps {
  clases: Clase[];
  reservarClase: (id: number) => void;
}

const ListaClases: React.FC<ListaClasesProps> = ({ clases, reservarClase }) => {
  if (!clases || clases.length === 0) {
    return <p>No hay clases disponibles.</p>;
  }

  return (
    <div>
      <h2>Clases Disponibles</h2>
      <ul>
        {clases.map((clase) => (
          <li key={clase.id}>
            {clase.nombre} - Cupos: {clase.cupos}
            <ReservaClase clase={clase} reservarClase={reservarClase} />
          </li>
        ))}
      </ul>
    </div>
  );
};

export default ListaClases;

