"use client";  // 👈 Indica que toda la página es un componente de cliente

import GymApp from "../components/GymApp";

export default function Home() {
  return (
    <div>
      <GymApp />
    </div>
  );
}
